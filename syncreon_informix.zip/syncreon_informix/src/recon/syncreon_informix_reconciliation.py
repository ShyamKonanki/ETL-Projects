# Databricks notebook source
import json
from pyspark.sql.types import *
from delta.tables import *

# COMMAND ----------

# widgets
dbutils.widgets.text("row", "", "Row")
row = json.loads(dbutils.widgets.get("row"))

# COMMAND ----------

source_folder = "/mnt/syncreon-informix/recon/"
active_target_folder = "/mnt/syncreon-informix/enrich/active/"

# COMMAND ----------

def reconciliation_tables(row):
    table_name = row["table_name"]
    print(table_name)
    schema_name = row["schema_name"]
    primary_key = row["primary_column"]
    primary_columns = primary_key.split(',')
    # Generate the join condition dynamically based on the primary columns
    join_condition = ' , '.join([f'table1_df.{col} == table2_df.new_{col}' for col in primary_columns])
    x2 = '['+join_condition+']'
    print(x2)
    source_folder_path = source_folder + schema_name + "/" + table_name
    active_target_path = active_target_folder + schema_name + "/" + table_name
    table2_df = spark.read.format("avro").option("header","true").load(source_folder_path)
    print("recon :" ,table2_df.count())
    table1_df = spark.read.format("delta").load(active_target_path)
    table1_df = table1_df.filter("_is_valid = '1'")
    print("delta :" ,table1_df.count())
    table1_df = table1_df.select(*primary_columns)
    table2_df = table2_df.select(*primary_columns)
    for i in table2_df.columns:
        table2_df = table2_df.withColumnRenamed(f"{i}",f"new_{i}")
    cond = ' and '.join([f'{col} is null' for col in table2_df.columns])
    drp = ','.join(f'{col}' for col in table2_df.columns)
    missing_keys_df = table1_df.alias("a").join(table2_df.alias("b"), eval(x2), "left")
    missing_keys_df = missing_keys_df.filter(f"{cond}")
    missing_keys_df = missing_keys_df.select("a.*").dropDuplicates()
    print(missing_keys_df.count())
    display(missing_keys_df)
    if (missing_keys_df.limit(1).count() > 0):
        target_active_df_current = DeltaTable.forPath(spark, active_target_path)
        join_condition = ' and '.join([f's.{col} == t.{col}' for col in primary_columns])
        (target_active_df_current.alias("t")
                    .merge(missing_keys_df.alias("s"), join_condition)
                    .whenMatchedUpdate(set = {
                                "_is_valid": "'0'"
                        })
                    .execute())
reconciliation_tables(row)    
