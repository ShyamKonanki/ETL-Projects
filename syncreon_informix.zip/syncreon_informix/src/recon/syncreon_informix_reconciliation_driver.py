# Databricks notebook source
# Imports
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from datetime import datetime
from delta.tables import *
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from pyspark.sql import functions as F
from pyspark.sql.types import *
import time

# COMMAND ----------

# Set Configuration
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", True)
spark.conf.set("spark.databricks.delta.merge.enableLowShuffle", True)
spark.conf.set("spark.databricks.io.cache.enabled", True)

# COMMAND ----------

# Widgets
dbutils.widgets.text("watermarktable", "adf_syncreon_informix_watermarktable_new", "WatermarkTable")

# COMMAND ----------

# Declarations
jdbcUrl = dbutils.secrets.get(scope="bi_secret_scope",key="secret-balookup-url")
connectionProperties = {}
driverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
connectionProperties["Driver"] = driverClass
connectionProperties["user"] = dbutils.secrets.get(scope="bi_secret_scope",key="secret-baadmin-username")
connectionProperties["password"] = dbutils.secrets.get(scope="bi_secret_scope",
key="secret-baadmin-password")
connectionProperties["trustServerCertificate"]= "true"
watermarkTable = dbutils.widgets.get("watermarktable")
query = f"( select * from {watermarkTable} ) watermarktable"
source_folder = "/mnt/syncreon-informix/recon/"
active_target_folder = "/mnt/syncreon-informix/enrich/active/"

# COMMAND ----------

ctrl_table = spark.read.jdbc(url=jdbcUrl, table=query, properties=connectionProperties)
ctrl_table_active = ctrl_table.where((col("isEnrichActive") == 1) & (col("isSnapshot")== 0 ))
#ctrl_table_active = ctrl_table_active.where("schema_name = 'informixpol' ") #and table_name = 'edi_linped' ")
listoftables = ctrl_table_active.toJSON().collect()
display(ctrl_table_active)

# COMMAND ----------

def reconciliation_tables(row):
    try:
        dbutils.notebook.run("./syncreon_informix_reconciliation", 0, {"row": row})
    except Exception as error:
        row = json.loads(row)
        print(f"Exception has occurred for Table {row['table_name']} and schema {row['schema_name']}")
        pass

# COMMAND ----------

with ThreadPoolExecutor(max_workers=10) as executor:
    results = executor.map(reconciliation_tables, listoftables)

# for row in listoftables:
#     dbutils.notebook.run("./syncreon_informix_reconciliation", 0, {"row": row})
#     time.sleep(2)    

# COMMAND ----------


