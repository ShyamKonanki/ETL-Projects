# Databricks notebook source
# Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
import time
from pyspark.sql.streaming import StreamingQueryListener
import json
from pyspark.sql.window import Window
from datetime import *
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import gc
import json
import glob

# COMMAND ----------

# Set Spark Conf
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", True)
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact", True)
spark.conf.set("spark.sql.streaming.noDataMicroBatches.enabled", False)
spark.conf.set("spark.sql.shuffle.partitions", sc.defaultParallelism)
spark.conf.set("spark.databricks.cloudFiles.recordEventChanges", True)
spark.conf.set("spark.databricks.cloudFiles.optimizedEventSerialization.enabled", True)
spark.conf.set("spark.databricks.delta.properties.defaults.enableChangeDataFeed", "true")

# COMMAND ----------

# widgets
dbutils.widgets.text("row", "", "Row")
row = json.loads(dbutils.widgets.get("row"))

# COMMAND ----------

# Main
def processing(batchdf, batchid, enrich_path, primary_columns, partition_column, is_snapshot, load_ts_col):
    timestamp = datetime.now()
    today = date.today()
    batchdf_trans = batchdf.withColumn("_filename", regexp_replace(input_file_name(), ":", ""))
    batchdf_trans = batchdf_trans.withColumnRenamed(load_ts_col, "_valid_from")
    batchdf_trans = batchdf_trans.withColumn("date_part", to_date(col("_valid_from")))
    batchdf_trans = batchdf_trans.withColumn("_valid_to", lit("9999-12-31T23:59:59"))
    batchdf_trans = batchdf_trans.withColumn("_is_valid", lit("1"))
    batchdf_trans = batchdf_trans.withColumn("_is_purged", lit("0"))
    display(batchdf_trans)
    primary_col_li = primary_columns.split(",")
    windowspec = Window.partitionBy([col(x) for x in primary_col_li]).orderBy(col("_valid_from").desc())
    
    key_condiiton = []
    for x in primary_col_li:
        key_condiiton.append(f"t.{x} = s.{x}")   
    key_condiiton_str = " AND ".join(key_condiiton)
    key_condiiton_str = key_condiiton_str + " AND t._is_purged = '0'"

    try:
#       Delta Changes are handled here
        if is_snapshot == 0:
            enrich_dt = DeltaTable.forPath(spark, enrich_path)
            print(f"processing delta {enrich_path}")
            batchdf_final = (batchdf_trans
                            .withColumn("rn", row_number().over(windowspec))              
                            .where(col("rn") == 1)
                            .drop("rn"))
            
            (enrich_dt.alias("t").merge(
                    batchdf_final.alias("s"),
                    f"{key_condiiton_str}")
                    .whenMatchedUpdateAll()
                    .whenNotMatchedInsertAll()
                    .execute())
        else:
            batchdf_final = (batchdf_trans
                                .withColumn("rn", row_number().over(windowspec))              
                                .where(col("rn") == 1)
                                .drop("rn"))
            
            print(f"creating delta table {enrich_path}")
            batchdf_final.write.mode("overwrite").partitionBy("_is_valid", partition_column).option("mergeSchema", "true").format("delta").save(enrich_path) 
        
    except Exception as e:
#       If Delta table does not exists, create enrich table
        if "is not a Delta table" in str(e):
            batchdf_final = (batchdf_trans
                                .withColumn("rn", row_number().over(windowspec))              
                                .where(col("rn") == 1)
                                .drop("rn"))
            
            print(f"creating delta table {enrich_path}")
            batchdf_final.write.mode("overwrite").partitionBy("_is_valid", partition_column).option("mergeSchema", "true").format("delta").save(enrich_path)         
        else:
            print(f"Error processing {enrich_path}")
    
    gc.collect()


try:
    primary_columns = row['primary_column']
    partition_column = 'date_part'
    base_url_enrich = row['base_path'] + "/enrich/"
    relative_path = row['relative_path']
    source_path = row['source_path']
    is_snapshot = row['isSnapshot']
    load_ts_col = 'etl_load_timestamp'
    unique_name = relative_path.replace("/", "")
    fl_format = "avro"
    raw_path = source_path + "/" + relative_path + "/"
    enrich_path = row['target_path']
    checkpoint_path = base_url_enrich + "_checkpoint/" + relative_path
    error_path = base_url_enrich + "_error/" + relative_path

    #deleting the enrich path, checkpoint_path, error_path if the table is snapshot type
    if is_snapshot == 1:
        dbutils.fs.rm(f'{enrich_path}', True)
        dbutils.fs.rm(f'{checkpoint_path}', True)
        dbutils.fs.rm(f'{error_path}', True)

    cloudFilesConf = {
    "cloudFiles.format": fl_format,
    "cloudFiles.useNotifications": "false",
    "cloudFiles.includeExistingFiles": "true",
    "cloudFiles.validateOptions": "true",
    "cloudFiles.schemaEvolutionMode": "rescue",
    "cloudFiles.inferColumnTypes": "true",
    "cloudFiles.schemaLocation": checkpoint_path,
    "cloudFiles.useIncrementalListing": "true",
    "cloudFiles.maxBytesPerTrigger": "10g",
    "cloudFiles.backfillInterval": "1 day"
    }

    AdditionalOptions = {"rescueDataColumn":"_rescued_data"}
    df = (spark.readStream.format("cloudFiles")
                    .options(**cloudFilesConf)
                    .options(**AdditionalOptions)
                    .option("pathGlobalFilter", f"*.{fl_format}")
                    .option("checkpointLocation", checkpoint_path)
                    .option("badRecordsPath", error_path)
                    .option("recursiveFileLookup", "true")
                    .load(raw_path))
    
    (df.writeStream.queryName(unique_name)
    .option("checkpointLocation", checkpoint_path)
    .trigger(availableNow=True)
    # .trigger(processingTime="2 second")
    .foreachBatch(lambda batchdf, batchid: processing(batchdf, batchid, enrich_path, primary_columns, partition_column, is_snapshot, load_ts_col))
    .start())

except Exception as e:
    print(e)
