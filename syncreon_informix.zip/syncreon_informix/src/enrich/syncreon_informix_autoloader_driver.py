# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import time

# COMMAND ----------

dbutils.widgets.text("watermarktable", "adf_syncreon_informix_watermarktable_new", "WatermarkTable")
dbutils.widgets.text("adfid", "", "ADF Run ID")


# COMMAND ----------

# Declarations
jdbcUrl = dbutils.secrets.get(scope="bi_secret_scope",key="secret-balookup-url")
connectionProperties = {}
driverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
connectionProperties["Driver"] = driverClass
connectionProperties["user"] = dbutils.secrets.get(scope="bi_secret_scope",key="secret-baadmin-username")
connectionProperties["password"] = dbutils.secrets.get(scope="bi_secret_scope",
key="secret-baadmin-password")
connectionProperties["trustServerCertificate"]= "true"
watermarkTable = dbutils.widgets.get("watermarktable")
query = f"( select * from {watermarkTable} ) watermarktable"

# COMMAND ----------

ctrl_table = spark.read.jdbc(url=jdbcUrl, table=query, properties=connectionProperties)
ctrl_schema = ctrl_table.schema
ctrl_table = ctrl_table.withColumn("data_start_time", when(col("data_start_time").isNull(), "0001-01-01T00:00:01").otherwise(col("data_start_time")))
ctrl_table = ctrl_table.withColumn("data_end_time", when(col("data_end_time").isNull(), "0001-01-01T00:00:01").otherwise(col("data_end_time")))
ctrl_table = ctrl_table.withColumn("start_date_part", when(col("start_date_part").isNull(), "0001-01-01").otherwise(col("start_date_part")))
ctrl_table = ctrl_table.withColumn("end_date_part", when(col("end_date_part").isNull(), "0001-01-01").otherwise(col("end_date_part")))
ctrl_table_inactive = ctrl_table.where(col("isEnrichActive") != 1)
ctrl_table_active = ctrl_table.where(col("isEnrichActive") == 1)

# COMMAND ----------

base_path = '/mnt/syncreon-informix'
source_path = '/mnt/syncreon-informix/raw'
ctrl_table_active = ctrl_table_active.withColumn("base_path", lit(base_path))
ctrl_table_active = ctrl_table_active.withColumn("source_path", lit(source_path))
ctrl_table_active = ctrl_table_active.withColumn("relative_path", concat_ws('/', col("schema_name"), col("table_name")))
ctrl_table_active = ctrl_table_active.withColumn("target_path", concat_ws('/', col("base_path"),lit("enrich/active"),col("relative_path")))
df_ctrl = ctrl_table_active.withColumn("unique_name", concat_ws('_', col("schema_name"), col("table_name")))
table_list = df_ctrl.toJSON().collect()
def autoloader_tables(row):
    try:
        dbutils.notebook.run("./syncreon_informix_raw_to_enrich_load", 0, {"row": row})
    except Exception as error:
        row = json.loads(row)
        print(f"Exception has occurred for Table {row['table_name']} and schema {row['schema_name']}")
        pass
with ThreadPoolExecutor(max_workers=10) as executor:
    results = executor.map(autoloader_tables, table_list)

# for row in table_list:
#     dbutils.notebook.run("./syncreon_informix_raw_to_enrich_load", 0, {"row": row})
#     time.sleep(10)

# COMMAND ----------


