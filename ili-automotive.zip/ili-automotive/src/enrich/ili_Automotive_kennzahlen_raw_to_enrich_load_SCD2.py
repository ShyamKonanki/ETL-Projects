# Databricks notebook source
# Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
import time
from pyspark.sql.streaming import StreamingQueryListener
import json
from pyspark.sql.window import Window
from datetime import *
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import gc
import json
import glob
import time

# COMMAND ----------

# Set Spark Conf
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", True)
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact", True)
spark.conf.set("spark.sql.streaming.noDataMicroBatches.enabled", False)
spark.conf.set("spark.sql.shuffle.partitions", sc.defaultParallelism)
spark.conf.set("spark.databricks.cloudFiles.recordEventChanges", True)
spark.conf.set("spark.databricks.cloudFiles.optimizedEventSerialization.enabled", True)
spark.conf.set("spark.databricks.delta.properties.defaults.enableChangeDataFeed", "true")

# COMMAND ----------

# widgets
dbutils.widgets.text("row", "", "Row")
row = json.loads(dbutils.widgets.get("row"))

# COMMAND ----------

def generate_hash_function(col_list, technical_columns=''):
    try:
        col_list_wo_technical = [x for x in col_list if x not in technical_columns]
        col_list_casted = "\t,".join(
            list(
                map(
                    lambda x: f"COALESCE(CAST(`{x}` AS STRING), '-')\n", col_list_wo_technical
                )
            )
        )
        res = f"SHA2(CONCAT_WS('||', \n\t{col_list_casted}), 512)"
        return res
    except Exception as e:
        print(f"Failed to generate hash function: {str(e)}")

# COMMAND ----------

# Main
def processing(batchdf, table_name, batchid, enrich_path, primary_columns, partition_column, is_snapshot, load_ts_col):
    timestamp = datetime.now()
    today = date.today()
    schema_name = "dbread"
    batchdf_trans = batchdf.withColumn("_filename", regexp_replace(input_file_name(), ":", ""))
    batchdf_trans = batchdf_trans.withColumn("_valid_from", to_date(col(load_ts_col)))
    batchdf_trans = batchdf_trans.withColumn("_is_valid", lit("1"))
    batchdf_trans = batchdf_trans.withColumn("_is_purged", lit("0"))
    primary_column_list = primary_columns.split(",")
    windowspec = Window.partitionBy("primary_hash_key").orderBy(col("_valid_from").desc())
    windowspec_hash_key = Window.partitionBy("value_hash_key").orderBy(col("_valid_from").desc())
    max_value_df = batchdf_trans.agg(max("_valid_from"))
    src_column_names = batchdf_trans.schema.names
    technical_name = ["etl_load_timestamp","_valid_from", "_valid_to", "_is_valid", "_filename", "datepart", "date_part"]
    batchdf_trans = batchdf_trans.selectExpr("*", generate_hash_function(src_column_names, technical_name) + "value_hash_key")
    batchdf_trans = batchdf_trans.selectExpr("*", generate_hash_function(primary_column_list, technical_name) + "primary_hash_key")
    batchdf_trans = (batchdf_trans.withColumn("rn", row_number().over(windowspec_hash_key))
                      .where("rn = 1")
                      .drop("rn"))

    max_values_list = max_value_df.collect()[0]
    max_date = str(max_values_list[0])
    end_date_part = str(row["end_date_part"])
    print(f"processing table {table_name} max date - {max_date}")
    inputs = primary_column_list
    output = ""
    for i in range(len(inputs)):
        output += inputs[i] + " is not null"
        if i < len(inputs) - 1:
            output += " and "
    filter_value=f"(_valid_from BETWEEN '{end_date_part}' and '{max_date}') and ({output})"
    source_df = batchdf_trans.filter(filter_value)
    source_df = source_df.withColumn("etl_load_timestamp", col("etl_load_timestamp").cast("string"))
    
    if source_df.limit(1).count() != 0:
        target_active_df = (source_df
                        .withColumn("rn", row_number().over(windowspec))
                        .withColumn("_valid_to", lag("_valid_from", 1).over(windowspec))
                        .withColumn("_valid_to", when(col("rn") == 1, "9999-12-31").otherwise(col("_valid_to")))
                        .withColumn("_is_valid", when(col("rn") == 1, '1').otherwise('0'))
                        .drop("rn"))

        try:
            target_active_df_current = DeltaTable.forPath(spark, enrich_path)
            print(f"updating new records for {schema_name}.{table_name}")
            target_active_current_df = target_active_df_current.toDF()
            
            stagedPart1 = (target_active_df.alias("updates")
                                .join(target_active_current_df.alias("enrich"), (col("updates.primary_hash_key") == col("enrich.primary_hash_key"))
                                                                & (col("updates.value_hash_key") != col("enrich.value_hash_key"))
                                                                )
                                .where("enrich._is_valid = '1' and updates._is_valid = '1'")
                                .selectExpr("updates.primary_hash_key as _merge_key", "updates.*"))

            stagedPart2 = (target_active_df.alias("updates")
                                .join(target_active_current_df.alias("enrich"), (col("updates.value_hash_key") == col("enrich.value_hash_key"))
                                                                & (col("updates._is_valid") == col("enrich._is_valid")), "leftanti")
                                .selectExpr("NULL as _merge_key", "updates.*"))
            stagedUpdates = stagedPart1.union(stagedPart2)

            stagedUpdates = stagedUpdates.withColumn("_min_ts", min(col("_valid_from")).over(windowspec_hash_key))
            (target_active_df_current.alias("t")
            .merge(stagedUpdates.alias("s"), f"t.primary_hash_key = s._merge_key and t._is_valid = '1'")
            .whenMatchedUpdate(set = {
                        "_valid_to": "s._valid_from",
                        "_is_valid": "'0'"
                })
            .whenNotMatchedInsertAll()
            .execute())
        except Exception as e:
              if "is not a Delta table" in str(e) or f"[PATH_NOT_FOUND] Path does not exist: {enrich_path}.":
                print(f"creating delta table {schema_name}.{table_name}")
                target_active_df.write.mode("overwrite").partitionBy("_is_valid", "_valid_from").format("delta").save(enrich_path)
              else:
                print(e)
                raise Exception(e)
    
    gc.collect()


try:
    primary_columns = row['primary_column']
    partition_column = 'date_part'
    base_url_enrich = row['base_path'] + "/enrich/"
    relative_path = row['relative_path']
    source_path = row['source_path']
    is_snapshot = row['isSnapshot']
    table_name = row['table_name']
    load_ts_col = 'etl_load_timestamp'
    unique_name = relative_path.replace("/", "")
    fl_format = "avro"
    raw_path = source_path + "/" + relative_path + "/"
    enrich_path = row['target_path']
    checkpoint_path = base_url_enrich + "_checkpoint/" + relative_path
    error_path = base_url_enrich + "_error/" + relative_path
    print("raw_path : ", raw_path)
    print("enrich_path : ", enrich_path)
    cloudFilesConf = {
    "cloudFiles.format": fl_format,
    "cloudFiles.useNotifications": "false",
    "cloudFiles.includeExistingFiles": "true",
    "cloudFiles.validateOptions": "true",
    "cloudFiles.schemaEvolutionMode": "rescue",
    "cloudFiles.inferColumnTypes": "true",
    "cloudFiles.schemaLocation": checkpoint_path,
    "cloudFiles.useIncrementalListing": "true",
    "cloudFiles.maxBytesPerTrigger": "10g",
    "cloudFiles.backfillInterval": "1 day"
    }

    # batchdf = spark.read.format('avro').load('/mnt/ili-automotive/raw/kennzahlen/view_kennzahlen_aktionen')
    # batchid = 1234
    # processing(batchdf, table_name, batchid, enrich_path, primary_columns, partition_column, is_snapshot, load_ts_col)
    
    AdditionalOptions = {"rescueDataColumn":"_rescued_data"}
    df = (spark.readStream.format("cloudFiles")
                    .options(**cloudFilesConf)
                    .options(**AdditionalOptions)
                    .option("pathGlobalFilter", f"*.{fl_format}")
                    .option("checkpointLocation", checkpoint_path)
                    .option("badRecordsPath", error_path)
                    .option("recursiveFileLookup", "true")
                    .load(raw_path))
    
    (df.writeStream.queryName(unique_name)
    .option("checkpointLocation", checkpoint_path)
    .trigger(availableNow=True)
    # .trigger(processingTime="2 second")
    .foreachBatch(lambda batchdf, batchid: processing(batchdf, table_name, batchid, enrich_path, primary_columns, partition_column, is_snapshot, load_ts_col))
    .start())

except Exception as e:
    print(e)
