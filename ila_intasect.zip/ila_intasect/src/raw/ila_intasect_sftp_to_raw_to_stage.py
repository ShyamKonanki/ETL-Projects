# Databricks notebook source
# Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
import time
from pyspark.sql.streaming import StreamingQueryListener
import json
from pyspark.sql.window import Window
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import json
import os
import gzip 
import shutil
import hashlib
import datetime

# COMMAND ----------

# MAGIC %run ../common/configuration

# COMMAND ----------

# Set Spark Conf
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", True)
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact", True)
spark.conf.set("spark.sql.streaming.noDataMicroBatches.enabled", False)
spark.conf.set("spark.sql.shuffle.partitions", sc.defaultParallelism)
spark.conf.set("spark.databricks.cloudFiles.recordEventChanges", True)
spark.conf.set("spark.databricks.cloudFiles.optimizedEventSerialization.enabled", True)
spark.conf.set("spark.databricks.delta.properties.defaults.enableChangeDataFeed", "true")

# COMMAND ----------

fl_format = "csv"
base_raw_path = "/mnt/ila-intasect/"
passphrase_fl = "/dbfs/mnt/ila-intasect/config/config_files/passphrase.txt"
privatekey_fl = "/dbfs/mnt/ila-intasect/config/config_files/private.asc"
processed_files = []
current_tm = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S')
current_dt = str(datetime.date.today())

# COMMAND ----------

# DBTITLE 1,Processing Raw
# Main
def autoloader_dbs():
    def processing(batchdf, batchid, dbname):
        li = batchdf.rdd.map(lambda x: x[0]).collect()
        print('li',li)
        for x in li:
            print('x',x)
            try:
                if x[-4:] == '.csv':
                    flpath = "/dbfs" + x
                    inputpathli = flpath.split("/")
                    flname = inputpathli[7]
                    outflbase = f"/mnt/ila-intasect/raw_sftp/intasect/active/{inputpathli[6]}/{flname.split('.')[0]}/"
                    dbutils.fs.mkdirs(outflbase)
                    print(outflbase)
                    outfl = "/dbfs" + outflbase + flname
                    
                    # decrypt the file and save to Raw layer in csv file format
                    os.system(f"gpg --no-tty --batch --import {privatekey_fl}")
                    os.system(f"gpg --no-tty --batch --yes --ignore-mdc-error --pinentry-mode=loopback --passphrase-fd 1 --passphrase-file {passphrase_fl} --output {outfl} --decrypt {flpath}")
                    
                    # save the file parquet file format in stage layer
                    tablename = flname.split('.')[0]
                    stage_path = base_raw_path + f"stage_sftp/intasect/{tablename}"
                    df = spark.read.csv(outflbase, sep="|", header = True).withColumn("filepath", input_file_name())
                    df = df.withColumn("datepart", element_at(split(col("filepath"), "/"), -3))
                    df.write.partitionBy("datepart").mode("append").format("parquet").save(stage_path)

                    log_tup = ('raw_stage_sftp', globals()['current_tm'], x, globals()['current_dt'], 'SUCCESS', 'PROCESSED')
                    processed_files.append(log_tup)
            except Exception as e:
                print(e)
                log_tup = ('raw_sftp', globals()['current_tm'], x, globals()['current_dt'], 'FAILED', str(e))
                processed_files.append(log_tup)

    try:
        dbname = 'intasect'
        checkpoint_path = base_raw_path + f"/raw_sftp/intasect/_checkpoint/"
        error_path = base_raw_path + f"/raw_sftp/intasect/_error/"
        raw_path = "/mnt/sftpprod/ila-intasect/landing/*/*"
        
        cloudFilesConf = {
        "cloudFiles.format": "csv",
        "cloudFiles.useNotifications": "false",
        "cloudFiles.includeExistingFiles": "true",
        "cloudFiles.validateOptions": "true",
        "cloudFiles.schemaEvolutionMode": "rescue",
        "cloudFiles.inferColumnTypes": "true",
        "cloudFiles.schemaLocation": checkpoint_path,
        "cloudFiles.useIncrementalListing": "true",
        "cloudFiles.maxBytesPerTrigger": "10g",
        "cloudFiles.backfillInterval": "1 day"
        }

        AdditionalOptions = {"rescueDataColumn":"_rescued_data"}
        spark.sparkContext.setLocalProperty("spark.scheduler.pool", dbname)
        df = (spark.readStream.format("cloudFiles")
                        .options(**cloudFilesConf)
                        .options(**AdditionalOptions)
                        .option("pathGlobalFilter", f"*.{fl_format}")
                        .option("checkpointLocation", checkpoint_path)
                        .option("badRecordsPath", error_path)
                        .option("recursiveFileLookup", "true")
                        .load(raw_path)
                        .withColumn("_filepath", input_file_name())
                        .select("_filepath").distinct())
        
        (df.writeStream.queryName(dbname)
        .option("checkpointLocation", checkpoint_path)
        .trigger(availableNow=True)
        # .trigger(processingTime="2 second")
        .foreachBatch(lambda batchdf, batchid: processing(batchdf, batchid, dbname))
        .start())
    except Exception as e:
        print(e)

autoloader_dbs()

# COMMAND ----------

delta_files_li = []
while 1 > 0:
    sqm = spark.streams
    active_streams = [q.name for q in sqm.active]
    if len(active_streams) == 0:
        log_schema = StructType([
            StructField("layer", StringType(), True),
            StructField("process_starttm", StringType(), True),
            StructField("filepath", StringType(), True),
            StructField("datepart", StringType(), True),
            StructField("status", StringType(), True),
            StructField("remark", StringType(), True)
        ])

        log_df = spark.createDataFrame(processed_files, log_schema)
        log_df.write.format("delta").mode("append").partitionBy("layer", "datepart").saveAsTable("ila_intasect_progress.pipeline_log_intasect")
        display(log_df)
        delta_files_li = log_df.collect()
        break
    else:
        time.sleep(10)

# COMMAND ----------

processed_files = []
distinct_tables = []
filtered_table_li = []
for fl in delta_files_li:
    tablename = fl.filepath.split("/")[-1].split(".")[0]
    distinct_tables.append(tablename)
set_tables = set(distinct_tables)
for tbl in table_list_intasect:
    tbl_str = tbl['tablename']
    if tbl_str in set_tables:
        filtered_table_li.append(tbl)


# COMMAND ----------

# Column between source and target is mismatching, so updated the column
if 'VEHCILEID' in spark.table('ila_intasect.sl_master_vehicles').columns and spark.catalog.tableExists("ila_intasect.sl_master_vehicles"):
    spark.sql("""ALTER TABLE ila_intasect.sl_master_vehicles SET TBLPROPERTIES (
   'delta.columnMapping.mode' = 'name',
   'delta.minReaderVersion' = '2',
   'delta.minWriterVersion' = '5');""")
    spark.sql("""ALTER TABLE ila_intasect.sl_master_vehicles
            RENAME COLUMN VEHCILEID TO VEHICLEID;""")


# COMMAND ----------

def autoloader_tables(row):
    json_row = json.dumps(row)
    return_val = dbutils.notebook.run("../enrich/ila_intasect_stage_to_enrich", 0, {"row": json_row})
    
    val_li = tuple(return_val.split(","))
    globals()['processed_files'].append(val_li)

with ThreadPoolExecutor(max_workers=25) as executor:
    results = executor.map(autoloader_tables, filtered_table_li)
# for i in filtered_table_li:
#     autoloader_tables(i)
#     time.sleep(10)

# COMMAND ----------

log_schema = StructType([
    StructField("layer", StringType(), True),
    StructField("process_starttm", StringType(), True),
    StructField("filepath", StringType(), True),
    StructField("datepart", StringType(), True),
    StructField("status", StringType(), True),
    StructField("remark", StringType(), True)
])

log_df = spark.createDataFrame(processed_files, log_schema)
log_df.write.format("delta").mode("append").partitionBy("layer", "datepart").saveAsTable("ila_intasect_progress.pipeline_log_intasect")
display(log_df)

# COMMAND ----------


