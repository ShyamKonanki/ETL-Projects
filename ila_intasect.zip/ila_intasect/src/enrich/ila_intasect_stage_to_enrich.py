# Databricks notebook source
# Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
from pyspark.sql.streaming import StreamingQueryListener
from pyspark.sql.window import Window
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import time
import json
import os
import gzip 
import shutil
import hashlib
import datetime

# COMMAND ----------

dbutils.widgets.text("row", "", "Row")
row_str = dbutils.widgets.get("row")
row = json.loads(row_str)

# COMMAND ----------

# Set Spark Conf
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", True)
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact", True)
spark.conf.set("spark.sql.streaming.noDataMicroBatches.enabled", False)
spark.conf.set("spark.sql.shuffle.partitions", sc.defaultParallelism)
spark.conf.set("spark.databricks.cloudFiles.recordEventChanges", True)
spark.conf.set("spark.databricks.cloudFiles.optimizedEventSerialization.enabled", True)
spark.conf.set("spark.databricks.delta.properties.defaults.enableChangeDataFeed", "true")

# COMMAND ----------

fl_format = "PARQUET"
base_raw_path = "/mnt/ila-intasect/"
processed_files = []
current_tm = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S')
current_dt = str(datetime.date.today())
return_val = """,,,,,"""

# COMMAND ----------

# Main
def processing(batchdf, batchid, dbname, tablename, enrich_path, key_cols):
    #df = (batchdf.withColumn("filepath", input_file_name())) 
    
    
    df = batchdf.withColumn("_valid_from", col("datepart").cast('int'))
    primary_col_li = key_cols.split(",")
    windowspec = Window.partitionBy([col(x) for x in primary_col_li]).orderBy(col("datepart").desc())
    df = (df
            .withColumn("rn", row_number().over(windowspec))
            .withColumn("_valid_to", lag("_valid_from", 1).over(windowspec))
            .withColumn("_valid_to", when(col("rn") == 1, "99991231").otherwise(col("_valid_to")))
            .withColumn("_is_valid", when(col("rn") == 1, '1').otherwise('0')))
    key_condiiton = []
    primary_cols = primary_col_li + ["_is_valid"]
    for x in primary_cols:
        key_condiiton.append(f"t.{x} = s.{x}")   
    key_condiiton_str = " AND ".join(key_condiiton)

    try:
        #   Delta Changes are handled here
        enrich_dt = DeltaTable.forPath(spark, enrich_path)
        print(f"processing delta {enrich_path}")
        # Remove duplicate
        df_final = (df.where(col("rn") == 1)
                .drop("rn"))
        target_columns = enrich_dt.toDF().columns
        source_columns = df_final.columns
        missing_columns_in_source = set(target_columns)-set(source_columns)
        missing_columns_in_target = set(source_columns)-set(target_columns)

        #Doing an inner join and getting source columns + missing source columns from delta table 
        actual_inner_data = df_final.alias('a').join(enrich_dt.toDF().alias('b'),primary_col_li).select("a.*", *missing_columns_in_source)
        #Doing left anti join and getting source columns + missing source columns from delta table(which will be null anyways) 
        actual_left_data = df_final.alias('a').join(enrich_dt.toDF().alias('b'),primary_col_li, 'left').filter(enrich_dt.toDF()[primary_col_li[0]].isNull()).select("a.*", *missing_columns_in_source)
        # making union of above dataframes which is the main source with all required columns
        df_final = actual_left_data.unionByName(actual_inner_data)
        df_final = (df_final
            .withColumn("rn", row_number().over(windowspec))
            .withColumn("_valid_to", lag("_valid_from", 1).over(windowspec))
            .withColumn("_valid_to", when(col("rn") == 1, "99991231").otherwise(col("_valid_to")))
            .withColumn("_is_valid", when(col("rn") == 1, '1').otherwise('0')))
        # Remove duplicate
        df_final = (df_final.where(col("rn") == 1)
                .drop("rn"))
        
        for x in missing_columns_in_target:
            spark.sql(f"ALTER TABLE delta.`{enrich_path}` add column {x} string")
        enrich_dt = DeltaTable.forPath(spark, enrich_path)
            
        (enrich_dt.alias("t").merge(
            df_final.alias("s"),
            f"{key_condiiton_str}")
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute())
        globals()['return_val'] = f"""enrich,{globals()['current_tm']},{enrich_path},{globals()['current_dt']},SUCCESS,PROCESSED"""

    except Exception as e:
    #   If Delta table does not exists, create enrich table
        if "is not a Delta table" in str(e):
            df_final = (df.withColumn("rn", row_number().over(windowspec))              
                        .where(col("rn") == 1)
                        .drop("rn"))
            
            print(f"creating delta table {enrich_path}")
            df_final.write.mode("overwrite").partitionBy("datepart").option("mergeSchema", "true").format("delta").save(enrich_path)
            spark.sql(f"create table if not exists ila_intasect.sl_{tablename} using delta location '{enrich_path}'")
            globals()['return_val'] = f"""enrich,{globals()['current_tm']},{enrich_path},{globals()['current_dt']},SUCCESS,PROCESSED"""

        else:
            print(f"Error processing {enrich_path}")
            globals()['return_val'] = f"""enrich,{globals()['current_tm']},{enrich_path},{globals()['current_dt']},FAILED,Delta tale error, {e}"""

try:
    dbname = 'intasect'
    tablename = row['tablename']
    key_cols = row['key_cols']
    checkpoint_path = base_raw_path + f"enrich/metadata/intasect/{tablename}/_checkpoint/"
    error_path = base_raw_path + f"enrich/metadata/intasect/{tablename}/_error/"
    enrich_path = base_raw_path + f"enrich/active/INTASECT/{tablename}"
    raw_path = base_raw_path + f"stage_sftp/intasect/{tablename}"
    print('raw_Path,', raw_path)
    unique_name = f"intasect{tablename}"
    return_val = f"""enrich,{globals()['current_tm']},{enrich_path},{globals()['current_dt']},SUCCESS,NO DATA"""

    cloudFilesConf = {
    "cloudFiles.format": "PARQUET",
    "cloudFiles.useNotifications": "false",
    "cloudFiles.includeExistingFiles": "true",
    "cloudFiles.validateOptions": "true",
    "cloudFiles.inferColumnTypes": "true",
    "cloudFiles.schemaLocation": checkpoint_path,
    "cloudFiles.useIncrementalListing": "true",
    "cloudFiles.maxBytesPerTrigger": "10g",
    "cloudFiles.backfillInterval": "1 day",
    "cloudFiles.partitionColumns":"datepart"
    }

    AdditionalOptions = {"rescueDataColumn":"_rescued_data"}
    spark.sparkContext.setLocalProperty("spark.scheduler.pool", unique_name)
    df = (spark.readStream.format("cloudFiles")
                    .options(**cloudFilesConf)
                    .options(**AdditionalOptions)
                    .option("pathGlobalFilter", f"*.{fl_format}")
                    .option("checkpointLocation", checkpoint_path)
                    .option("badRecordsPath", error_path)
                    .option("pathGlobFilter", "*.parquet")
                    #.option("recursiveFileLookup", "true")
                    .load(raw_path)
                    ) 
    (df.writeStream.queryName(unique_name)
    .option("checkpointLocation", checkpoint_path)
    .trigger(availableNow=True)
    # .trigger(processingTime="2 second")
    .foreachBatch(lambda batchdf, batchid: processing(batchdf, batchid, dbname, tablename, enrich_path, key_cols))
    .start())

except Exception as e:
    print(e)
    return_val = f"""enrich,{globals()['current_tm']},{row_str},{globals()['current_dt']},FAILED,Incorrect Input"""

# COMMAND ----------

while 1 > 0:
    sqm = spark.streams
    active_streams = [q.name for q in sqm.active]
    if len(active_streams) == 0:
        dbutils.notebook.exit(return_val)
        break
    else:
        time.sleep(10)

# COMMAND ----------


