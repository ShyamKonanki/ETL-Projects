# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS ila_intasect_progress

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE ila_intasect_progress.pipeline_log_intasect (
# MAGIC   layer STRING,
# MAGIC   process_starttm STRING,
# MAGIC   filepath STRING,
# MAGIC   datepart STRING,
# MAGIC   status STRING,
# MAGIC   remark STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (layer, datepart)
# MAGIC LOCATION '/mnt/ila-intasect/config/logs/pipeline_log_intasect'

# COMMAND ----------


table_list_intasect = [
    {"tablename": "master_customers", "key_cols": "CUSTID", "encrypt_cols": []},
    {"tablename": "master_depot", "key_cols": "DEPOTID", "encrypt_cols": []},
    {"tablename": "master_drivers", "key_cols": "DRIVERID", "encrypt_cols": []},
    {"tablename": "master_makes", "key_cols": "MAKEID", "encrypt_cols": []},
    {"tablename": "master_sizes", "key_cols": "SIZEID", "encrypt_cols": []},
    {"tablename": "master_suppliers", "key_cols": "SUPPLIERID", "encrypt_cols": []},
    {"tablename": "master_treads", "key_cols": "TREADID", "encrypt_cols": []},
    {"tablename": "master_tyres", "key_cols": "TYREID", "encrypt_cols": []},
    {"tablename": "master_vehicles", "key_cols": "VEHICLEID", "encrypt_cols": []},
    {"tablename": "trans_batches", "key_cols": "BATCHID", "encrypt_cols": []},
    {"tablename": "trans_breakdown", "key_cols": "ID", "encrypt_cols": []},
    {"tablename": "trans_breakdownparts", "key_cols": "ID", "encrypt_cols": []},
    {"tablename": "trans_calloutsuppliers", "key_cols": "ID", "encrypt_cols": []},
    {"tablename": "trans_tyrecosts", "key_cols": "TYREID,DATETICKS", "encrypt_cols": []},
    {"tablename": "trans_tyrelocation", "key_cols": "TYREID,DATETICKS", "encrypt_cols": []},
    {"tablename": "trans_tyrewear", "key_cols": "TYREID,DATETICKS", "encrypt_cols": []}
]
